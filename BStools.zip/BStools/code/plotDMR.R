# function and example code for DMR visualization
# 
# Main function plotRegion()
# 1) generate summarized information for all tumor and normal sampels in targeted region, as a lit. The first element
#    of the list the 
# 2) plot methylation levels for all tumor and normal sampels in targeted region


# example script
install.packages("plotrix")
library("plotrix")

tumor<-c("S1","S2","S3")
normal<-c("N1", "N2","N3")

example.region<-plotRegion(normal, tumor, "chr5", 76249822, 76249807, "DMR.example.ps")




# visualization functions
get.summary.table<-function(coverage.mat, mC.mat, sample.name){
  sumary.table<-matrix(NA, ncol=4, nrow=0)
  for (i in 3:dim(coverage.mat)[2]){
     nocov.index<-(1:dim(coverage.mat)[1])[coverage.mat[,i]==0]
     covered_CG<-dim(coverage.mat)[1]-length( nocov.index)
     covered_CG_percent<-((dim(coverage.mat)[1]-length(nocov.index))/dim(coverage.mat)[1])*100
     if ((dim(coverage.mat)[1]-length(nocov.index)) >0){
        mean_mC<-mean(mC.mat[-nocov.index,i])
        mean_cov<-mean(coverage.mat[-nocov.index,i])
     }
     else {
        mean_mC<-NA
        mean_cov<-0
     }
     vec<-c(covered_CG, covered_CG_percent,mean_mC, mean_cov)
     sumary.table<-rbind(sumary.table, vec)
  }
  final<-t(sumary.table)
  rownames(final) <- c("covered_CG", "covered_CG(%)", "mean_mC", "mean_coverage")
  colnames(final)<-sample.name
  return(signif(final,2))
}



plot.gene<-function( tumor.mC.mat, normal.mC.mat, ps.name){
       library("plotrix")
       postscript(ps.name, paper="letter")
       par(mar=c(10,4,2,2))
       plot_CG<-cbind(region_normal_mc[,-2],region_tumor_mc[,-c(1,2)])
       plot(0, ylim=c(1,length(tumor_samples)+length(normal_samples)), xlim=c(0.5, 26.5), type="n", axes=FALSE, ylab="", xlab="position in bp")
       axis(2, at=c(1:length(tumor_samples)+length(normal_samples)), labels=c("N3","N2","N1","T3","T2","T1"), cex.axis=1.3, las=2)
       axis(1, at=c(1:dim(plot_CG)[1], labels=plot_CG[,1], cex.axis=0.5, las=2)

       # plot normal samples
       for (i in 1:length(normal_samples)){
          abline(h=i, lwd=4 , col="magenta")
          for (j in 1:dim(plot_CG)[1]){
             if (!is.na(plot_CG[j,i+1]) & as.numeric(plot_CG[j,i+1])==0){
                  floating.pie(j,i, c(1), radius=0.4, col=c("white"), startpos=pi/2)
              }  
             else if (!is.na(plot_CG[j,i+1]){
               floating.pie(j,i, c(plot_CG[j,i+1], 1-plot_CG[j,i+1]), radius=0.4, col=c("magenta", "white"), startpos=pi/2-plot_CG[j,i+1]*2*pi)
             }
           }  
       }

      # plot tumor samples
      for (i in (length(normal_samples)+1):(length(tumor_samples)+length(normal_samples))){
          abline(h=i, lwd=4 , col="blue")
          for (j in 1:dim(plot_CG)[1]){
            if (!is.na(plot_CG[j,i+1]) & as.numeric(plot_CG[j,i+1])==0){
                floating.pie(j,i, c(1), radius=0.5, col=c("white"), startpos=pi/2)
            }
            else if (!is.na(plot_CG[j,i+1])) {
                floating.pie(j,i, c(plot_CG[j,i+1], 1-plot_CG[j,i+1]), radius=0.5, col=c("blue", "white"), startpos=pi/2-plot_CG[j,i+1]*2*pi)
            }
         }
     }

     dev.off()
}




plotRegion<-function(normal_samples, tumor_samples, chr, start, end, plotPath ){
	  
       normal_sample_path<-sapply(1:length(normal_samples), function(x) return(paste(normal_samples[x], "/",  unlist(strsplit(normal_samples[x], "/"))[2], ".CG.base", sep="")))
       tumor_sample_path<-sapply(1:length(tumor_samples), function(x) return(paste(tumor_samples[x], "/",  unlist(strsplit(tumor_samples[x], "/"))[2], ".CG.base", sep="")))

       tumor_sample_chr<-paste(tumor_samples, "/CG.", chr,  sep="")
       normal_sample_chr<-paste(normal_samples, "/CG.", chr,  sep="")

       
       for (j in 1:length(tumor_samples)){

       		 if(!file.exists(tumor_sample_chr[j])){
                     system(paste("  awk  \'$1 ~ /^", chr, "$/{print}\' ",tumor_sample_path[j]," > ", tumor_sample_chr[j],sep=''))
		         }
		     tumor<-read.table(tumor_sample_chr[j])

		     if (j==1){
		       tumor_mC_mat<-tumor[,c(1,2,4)]
               tumor_cov_mat<-tumor[,c(1,2,3)]
		     }
             else {
               tumor_mC_mat<-cbind(tumor_mC_mat, tumor[,4])
               tumor_cov_mat<-cbind(tumor_cov_mat, tumor[,3])
             }

       }


       for (k in 1:length(normal_samples)){

       		 if(!file.exists(normal_sample_chr[k])){
                     system(paste("  awk  \'$1 ~ /^", chr, "$/{print}\' ",normal_sample_path[k]," > ", normal_sample_chr[k],sep=''))
		         }
		     normal<-read.table(normal_sample_chr[k])

		     if (k==1){
		       normal_mC_mat<-normal[,c(1,2,4)]
               normal_cov_mat<-normal[,c(1,2,3)]
		     }
             else {
               normal_mC_mat<-cbind(normal_mC_mat, normal[,4])
               normal_cov_mat<-cbind(normal_cov_mat, normal[,3])
             }

       }
       region_tumor_mc<-tumor_mC_mat[tumor_mC_mat[,1]==chr & tumor_mC_mat[,2]<=end & tumor_mC_mat[,2]>=start,]
       region_tumor_cov<-tumor_cov_mat[tumor_cov_mat[,1]==chr & tumor_cov_mat[,2]<=end & tumor_cov_mat[,2]>=start,]
       region_normal_mc<-normal_mC_mat[normal_mC_mat[,1]==chr & normal_mC_mat[,2]<=end & normal_mC_mat[,2]>=start,]
       region_normal_cov<-normal_cov_mat[normal_cov_mat[,1]==chr & normal_cov_mat[,2]<=end & normal_cov_mat[,2]>=start,]


       tumor_summary<-get.summary.table(region_tumor_cov, region_tumor_mc, sapply(1:length(tumor_samples), function(x) {unlist(strsplit(tumor_samples[x], "/"))[2]}))
       normal_summary<-get.summary.table(region_normal_cov, region_normal_mc, sapply(1:length(normal_samples), function(x) {unlist(strsplit(normal_samples[x], "/"))[2]}))


       plot.gene( region_tumor_mc,  region_normal_mc,plotPath )
       return(list(tumor_summary, normal_summary))
}

